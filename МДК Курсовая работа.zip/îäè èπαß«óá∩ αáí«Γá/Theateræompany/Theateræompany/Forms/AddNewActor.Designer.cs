﻿namespace TheaterСompany.Forms
{
    partial class AddNewActor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddNewActor));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.databaseTheatreDataSet = new TheaterСompany.DatabaseTheatreDataSet();
            this.actorMainsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.actorMainsTableAdapter = new TheaterСompany.DatabaseTheatreDataSetTableAdapters.ActorMainsTableAdapter();
            this.iDActorMainsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.familiaACDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.imaACDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.stagJobDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseTheatreDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actorMainsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDActorMainsDataGridViewTextBoxColumn,
            this.familiaACDataGridViewTextBoxColumn,
            this.imaACDataGridViewTextBoxColumn,
            this.stagJobDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.actorMainsBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 57);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(408, 278);
            this.dataGridView1.TabIndex = 0;
            // 
            // databaseTheatreDataSet
            // 
            this.databaseTheatreDataSet.DataSetName = "DatabaseTheatreDataSet";
            this.databaseTheatreDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // actorMainsBindingSource
            // 
            this.actorMainsBindingSource.DataMember = "ActorMains";
            this.actorMainsBindingSource.DataSource = this.databaseTheatreDataSet;
            // 
            // actorMainsTableAdapter
            // 
            this.actorMainsTableAdapter.ClearBeforeFill = true;
            // 
            // iDActorMainsDataGridViewTextBoxColumn
            // 
            this.iDActorMainsDataGridViewTextBoxColumn.DataPropertyName = "ID_ActorMains";
            this.iDActorMainsDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDActorMainsDataGridViewTextBoxColumn.Name = "iDActorMainsDataGridViewTextBoxColumn";
            this.iDActorMainsDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDActorMainsDataGridViewTextBoxColumn.Width = 30;
            // 
            // familiaACDataGridViewTextBoxColumn
            // 
            this.familiaACDataGridViewTextBoxColumn.DataPropertyName = "Familia_AC";
            this.familiaACDataGridViewTextBoxColumn.FillWeight = 120F;
            this.familiaACDataGridViewTextBoxColumn.HeaderText = "Фамилия";
            this.familiaACDataGridViewTextBoxColumn.Name = "familiaACDataGridViewTextBoxColumn";
            // 
            // imaACDataGridViewTextBoxColumn
            // 
            this.imaACDataGridViewTextBoxColumn.DataPropertyName = "Ima_AC";
            this.imaACDataGridViewTextBoxColumn.FillWeight = 120F;
            this.imaACDataGridViewTextBoxColumn.HeaderText = "Имя";
            this.imaACDataGridViewTextBoxColumn.Name = "imaACDataGridViewTextBoxColumn";
            // 
            // stagJobDataGridViewTextBoxColumn
            // 
            this.stagJobDataGridViewTextBoxColumn.DataPropertyName = "StagJob";
            this.stagJobDataGridViewTextBoxColumn.HeaderText = "Стаж работы (лет)";
            this.stagJobDataGridViewTextBoxColumn.Name = "stagJobDataGridViewTextBoxColumn";
            this.stagJobDataGridViewTextBoxColumn.Width = 130;
            // 
            // AddNewActor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(432, 401);
            this.Controls.Add(this.dataGridView1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddNewActor";
            this.Text = "Список актеров";
            this.Load += new System.EventHandler(this.AddNewActor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseTheatreDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actorMainsBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private DatabaseTheatreDataSet databaseTheatreDataSet;
        private System.Windows.Forms.BindingSource actorMainsBindingSource;
        private DatabaseTheatreDataSetTableAdapters.ActorMainsTableAdapter actorMainsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDActorMainsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn familiaACDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn imaACDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn stagJobDataGridViewTextBoxColumn;
    }
}