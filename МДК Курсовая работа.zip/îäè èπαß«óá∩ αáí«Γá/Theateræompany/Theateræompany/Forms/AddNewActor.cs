﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheaterСompany.Forms
{
    public partial class AddNewActor : Form
    {
        public AddNewActor()
        {
            InitializeComponent();
        }

        private void AddNewActor_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "databaseTheatreDataSet.ActorMains". При необходимости она может быть перемещена или удалена.
            this.actorMainsTableAdapter.Fill(this.databaseTheatreDataSet.ActorMains);

        }
    }
}
