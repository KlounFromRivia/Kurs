﻿namespace TheaterСompany.Forms
{
    partial class TheatresForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TheatresForm));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.iDTheatersDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.theaterNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.adressDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ratingDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fIODirectorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.phoneDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.theatersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.databaseTheatreDataSet = new TheaterСompany.DatabaseTheatreDataSet();
            this.theatersTableAdapter = new TheaterСompany.DatabaseTheatreDataSetTableAdapters.TheatersTableAdapter();
            this.btnAddTheatre = new System.Windows.Forms.Button();
            this.btnDeleteTheatre = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.theatersBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseTheatreDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDTheatersDataGridViewTextBoxColumn,
            this.theaterNameDataGridViewTextBoxColumn,
            this.adressDataGridViewTextBoxColumn,
            this.ratingDataGridViewTextBoxColumn,
            this.fIODirectorDataGridViewTextBoxColumn,
            this.phoneDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.theatersBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(12, 29);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(626, 236);
            this.dataGridView1.TabIndex = 0;
            // 
            // iDTheatersDataGridViewTextBoxColumn
            // 
            this.iDTheatersDataGridViewTextBoxColumn.DataPropertyName = "ID_Theaters";
            this.iDTheatersDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDTheatersDataGridViewTextBoxColumn.Name = "iDTheatersDataGridViewTextBoxColumn";
            this.iDTheatersDataGridViewTextBoxColumn.ReadOnly = true;
            this.iDTheatersDataGridViewTextBoxColumn.Width = 30;
            // 
            // theaterNameDataGridViewTextBoxColumn
            // 
            this.theaterNameDataGridViewTextBoxColumn.DataPropertyName = "TheaterName";
            this.theaterNameDataGridViewTextBoxColumn.HeaderText = "Название";
            this.theaterNameDataGridViewTextBoxColumn.Name = "theaterNameDataGridViewTextBoxColumn";
            // 
            // adressDataGridViewTextBoxColumn
            // 
            this.adressDataGridViewTextBoxColumn.DataPropertyName = "Adress";
            this.adressDataGridViewTextBoxColumn.HeaderText = "Адрес";
            this.adressDataGridViewTextBoxColumn.Name = "adressDataGridViewTextBoxColumn";
            // 
            // ratingDataGridViewTextBoxColumn
            // 
            this.ratingDataGridViewTextBoxColumn.DataPropertyName = "Rating";
            this.ratingDataGridViewTextBoxColumn.HeaderText = "Рейтинг";
            this.ratingDataGridViewTextBoxColumn.Name = "ratingDataGridViewTextBoxColumn";
            // 
            // fIODirectorDataGridViewTextBoxColumn
            // 
            this.fIODirectorDataGridViewTextBoxColumn.DataPropertyName = "FIO_Director";
            this.fIODirectorDataGridViewTextBoxColumn.HeaderText = "Фио директора";
            this.fIODirectorDataGridViewTextBoxColumn.Name = "fIODirectorDataGridViewTextBoxColumn";
            // 
            // phoneDataGridViewTextBoxColumn
            // 
            this.phoneDataGridViewTextBoxColumn.DataPropertyName = "Phone";
            this.phoneDataGridViewTextBoxColumn.HeaderText = "Номер телефона директора";
            this.phoneDataGridViewTextBoxColumn.Name = "phoneDataGridViewTextBoxColumn";
            this.phoneDataGridViewTextBoxColumn.Width = 150;
            // 
            // theatersBindingSource
            // 
            this.theatersBindingSource.DataMember = "Theaters";
            this.theatersBindingSource.DataSource = this.databaseTheatreDataSet;
            // 
            // databaseTheatreDataSet
            // 
            this.databaseTheatreDataSet.DataSetName = "DatabaseTheatreDataSet";
            this.databaseTheatreDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // theatersTableAdapter
            // 
            this.theatersTableAdapter.ClearBeforeFill = true;
            // 
            // btnAddTheatre
            // 
            this.btnAddTheatre.Location = new System.Drawing.Point(90, 303);
            this.btnAddTheatre.Name = "btnAddTheatre";
            this.btnAddTheatre.Size = new System.Drawing.Size(94, 34);
            this.btnAddTheatre.TabIndex = 1;
            this.btnAddTheatre.Text = "Добавить";
            this.btnAddTheatre.UseVisualStyleBackColor = true;
            this.btnAddTheatre.Click += new System.EventHandler(this.btnAddTheatre_Click);
            // 
            // btnDeleteTheatre
            // 
            this.btnDeleteTheatre.Location = new System.Drawing.Point(389, 303);
            this.btnDeleteTheatre.Name = "btnDeleteTheatre";
            this.btnDeleteTheatre.Size = new System.Drawing.Size(94, 34);
            this.btnDeleteTheatre.TabIndex = 2;
            this.btnDeleteTheatre.Text = "Удалить";
            this.btnDeleteTheatre.UseVisualStyleBackColor = true;
            // 
            // TheatresForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 366);
            this.Controls.Add(this.btnDeleteTheatre);
            this.Controls.Add(this.btnAddTheatre);
            this.Controls.Add(this.dataGridView1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TheatresForm";
            this.Text = "Список театров";
            this.Load += new System.EventHandler(this.TheatresForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.theatersBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseTheatreDataSet)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDTheatersDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn theaterNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn adressDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ratingDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fIODirectorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn phoneDataGridViewTextBoxColumn;
        private System.Windows.Forms.Button btnAddTheatre;
        private System.Windows.Forms.Button btnDeleteTheatre;
        public DatabaseTheatreDataSet databaseTheatreDataSet;
        public System.Windows.Forms.BindingSource theatersBindingSource;
        public DatabaseTheatreDataSetTableAdapters.TheatersTableAdapter theatersTableAdapter;
    }
}