﻿namespace TheaterСompany.Forms
{
    partial class PerformancesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PerformancesForm));
            this.grbPerfom = new System.Windows.Forms.GroupBox();
            this.dgvTicket = new System.Windows.Forms.DataGridView();
            this.bindingSourcePermof = new System.Windows.Forms.BindingSource(this.components);
            this.databaseTheatreDataSet = new TheaterСompany.DatabaseTheatreDataSet();
            this.performancesTableAdapter = new TheaterСompany.DatabaseTheatreDataSetTableAdapters.PerformancesTableAdapter();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbFilter = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.theatersBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.theatersTableAdapter = new TheaterСompany.DatabaseTheatreDataSetTableAdapters.TheatersTableAdapter();
            this.ColumnID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnPerfomens = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTheatre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnPrice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnActor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnDatePer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnInfo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lstbSort = new System.Windows.Forms.ListBox();
            this.grpbSort = new System.Windows.Forms.GroupBox();
            this.rdbVozrat = new System.Windows.Forms.RadioButton();
            this.rdbUbiv = new System.Windows.Forms.RadioButton();
            this.btnSortPer = new System.Windows.Forms.Button();
            this.grbPerfom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTicket)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourcePermof)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseTheatreDataSet)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.theatersBindingSource)).BeginInit();
            this.grpbSort.SuspendLayout();
            this.SuspendLayout();
            // 
            // grbPerfom
            // 
            this.grbPerfom.Controls.Add(this.dgvTicket);
            this.grbPerfom.Location = new System.Drawing.Point(12, 36);
            this.grbPerfom.Name = "grbPerfom";
            this.grbPerfom.Size = new System.Drawing.Size(992, 381);
            this.grbPerfom.TabIndex = 8;
            this.grbPerfom.TabStop = false;
            this.grbPerfom.Text = "Выступления";
            // 
            // dgvTicket
            // 
            this.dgvTicket.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTicket.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnID,
            this.ColumnPerfomens,
            this.ColumnTheatre,
            this.ColumnPrice,
            this.ColumnActor,
            this.ColumnDatePer,
            this.ColumnInfo});
            this.dgvTicket.Location = new System.Drawing.Point(6, 19);
            this.dgvTicket.Name = "dgvTicket";
            this.dgvTicket.Size = new System.Drawing.Size(980, 356);
            this.dgvTicket.TabIndex = 0;
            // 
            // bindingSourcePermof
            // 
            this.bindingSourcePermof.DataMember = "Performances";
            this.bindingSourcePermof.DataSource = this.databaseTheatreDataSet;
            // 
            // databaseTheatreDataSet
            // 
            this.databaseTheatreDataSet.DataSetName = "DatabaseTheatreDataSet";
            this.databaseTheatreDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // performancesTableAdapter
            // 
            this.performancesTableAdapter.ClearBeforeFill = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Controls.Add(this.cmbFilter);
            this.groupBox1.Location = new System.Drawing.Point(832, 423);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(172, 100);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Фильтрация";
            // 
            // cmbFilter
            // 
            this.cmbFilter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFilter.FormattingEnabled = true;
            this.cmbFilter.Items.AddRange(new object[] {
            "Название",
            "Театр",
            "Цена"});
            this.cmbFilter.Location = new System.Drawing.Point(7, 20);
            this.cmbFilter.Name = "cmbFilter";
            this.cmbFilter.Size = new System.Drawing.Size(159, 21);
            this.cmbFilter.TabIndex = 0;
            this.cmbFilter.SelectedIndexChanged += new System.EventHandler(this.cmbFilter_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(30, 65);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // theatersBindingSource
            // 
            this.theatersBindingSource.DataMember = "Theaters";
            this.theatersBindingSource.DataSource = this.databaseTheatreDataSet;
            // 
            // theatersTableAdapter
            // 
            this.theatersTableAdapter.ClearBeforeFill = true;
            // 
            // ColumnID
            // 
            this.ColumnID.HeaderText = "ID";
            this.ColumnID.Name = "ColumnID";
            this.ColumnID.Width = 30;
            // 
            // ColumnPerfomens
            // 
            this.ColumnPerfomens.HeaderText = "Название";
            this.ColumnPerfomens.Name = "ColumnPerfomens";
            this.ColumnPerfomens.Width = 150;
            // 
            // ColumnTheatre
            // 
            this.ColumnTheatre.HeaderText = "Театр";
            this.ColumnTheatre.Name = "ColumnTheatre";
            this.ColumnTheatre.Width = 120;
            // 
            // ColumnPrice
            // 
            this.ColumnPrice.HeaderText = "Цена";
            this.ColumnPrice.Name = "ColumnPrice";
            this.ColumnPrice.Width = 150;
            // 
            // ColumnActor
            // 
            this.ColumnActor.HeaderText = "Актер (главная роль)";
            this.ColumnActor.Name = "ColumnActor";
            this.ColumnActor.Width = 200;
            // 
            // ColumnDatePer
            // 
            this.ColumnDatePer.HeaderText = "Дата выступления";
            this.ColumnDatePer.Name = "ColumnDatePer";
            this.ColumnDatePer.Width = 130;
            // 
            // ColumnInfo
            // 
            this.ColumnInfo.HeaderText = "Информация";
            this.ColumnInfo.Name = "ColumnInfo";
            this.ColumnInfo.Width = 150;
            // 
            // lstbSort
            // 
            this.lstbSort.FormattingEnabled = true;
            this.lstbSort.Items.AddRange(new object[] {
            "Название",
            "Театр",
            "Цена"});
            this.lstbSort.Location = new System.Drawing.Point(6, 20);
            this.lstbSort.Name = "lstbSort";
            this.lstbSort.Size = new System.Drawing.Size(171, 95);
            this.lstbSort.TabIndex = 10;
            this.lstbSort.SelectedIndexChanged += new System.EventHandler(this.lstbSort_SelectedIndexChanged);
            // 
            // grpbSort
            // 
            this.grpbSort.Controls.Add(this.btnSortPer);
            this.grpbSort.Controls.Add(this.rdbUbiv);
            this.grpbSort.Controls.Add(this.rdbVozrat);
            this.grpbSort.Controls.Add(this.lstbSort);
            this.grpbSort.Location = new System.Drawing.Point(643, 423);
            this.grpbSort.Name = "grpbSort";
            this.grpbSort.Size = new System.Drawing.Size(183, 210);
            this.grpbSort.TabIndex = 11;
            this.grpbSort.TabStop = false;
            this.grpbSort.Text = "Сортировка";
            // 
            // rdbVozrat
            // 
            this.rdbVozrat.AutoSize = true;
            this.rdbVozrat.Location = new System.Drawing.Point(7, 122);
            this.rdbVozrat.Name = "rdbVozrat";
            this.rdbVozrat.Size = new System.Drawing.Size(170, 17);
            this.rdbVozrat.TabIndex = 11;
            this.rdbVozrat.TabStop = true;
            this.rdbVozrat.Text = "Сортировка по возрастанию";
            this.rdbVozrat.UseVisualStyleBackColor = true;
            // 
            // rdbUbiv
            // 
            this.rdbUbiv.AutoSize = true;
            this.rdbUbiv.Location = new System.Drawing.Point(7, 146);
            this.rdbUbiv.Name = "rdbUbiv";
            this.rdbUbiv.Size = new System.Drawing.Size(154, 17);
            this.rdbUbiv.TabIndex = 12;
            this.rdbUbiv.TabStop = true;
            this.rdbUbiv.Text = "Сортировка по убыванию";
            this.rdbUbiv.UseVisualStyleBackColor = true;
            // 
            // btnSortPer
            // 
            this.btnSortPer.Enabled = false;
            this.btnSortPer.Location = new System.Drawing.Point(30, 169);
            this.btnSortPer.Name = "btnSortPer";
            this.btnSortPer.Size = new System.Drawing.Size(122, 35);
            this.btnSortPer.TabIndex = 12;
            this.btnSortPer.Text = "Сортировать";
            this.btnSortPer.UseVisualStyleBackColor = true;
            this.btnSortPer.Click += new System.EventHandler(this.btnSortPer_Click);
            // 
            // PerformancesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1016, 645);
            this.Controls.Add(this.grpbSort);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.grbPerfom);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "PerformancesForm";
            this.Text = "Список выступлений";
            this.Load += new System.EventHandler(this.PerformancesForm_Load);
            this.grbPerfom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTicket)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingSourcePermof)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseTheatreDataSet)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.theatersBindingSource)).EndInit();
            this.grpbSort.ResumeLayout(false);
            this.grpbSort.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grbPerfom;
        private System.Windows.Forms.DataGridView dgvTicket;
        private System.Windows.Forms.BindingSource bindingSourcePermof;
        private DatabaseTheatreDataSet databaseTheatreDataSet;
        private DatabaseTheatreDataSetTableAdapters.PerformancesTableAdapter performancesTableAdapter;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox cmbFilter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.BindingSource theatersBindingSource;
        private DatabaseTheatreDataSetTableAdapters.TheatersTableAdapter theatersTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnPerfomens;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTheatre;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnPrice;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnActor;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnDatePer;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnInfo;
        private System.Windows.Forms.ListBox lstbSort;
        private System.Windows.Forms.GroupBox grpbSort;
        private System.Windows.Forms.Button btnSortPer;
        private System.Windows.Forms.RadioButton rdbUbiv;
        private System.Windows.Forms.RadioButton rdbVozrat;
    }
}