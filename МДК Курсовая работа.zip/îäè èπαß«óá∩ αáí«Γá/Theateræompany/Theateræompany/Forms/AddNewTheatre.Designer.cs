﻿namespace TheaterСompany.Forms
{
    partial class AddNewTheatre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddNewTheatre));
            this.label5 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.nudIDt = new System.Windows.Forms.NumericUpDown();
            this.txtNameTheatre = new System.Windows.Forms.TextBox();
            this.txtAdress = new System.Windows.Forms.TextBox();
            this.nudRaiting = new System.Windows.Forms.NumericUpDown();
            this.txtNameDirec = new System.Windows.Forms.TextBox();
            this.mtxtPhoneDirec = new System.Windows.Forms.MaskedTextBox();
            this.btnAddNewTheatre = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudIDt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudRaiting)).BeginInit();
            this.SuspendLayout();
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(44, 18);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(282, 25);
            this.label5.TabIndex = 31;
            this.label5.Text = "Добавление нового театра";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(18, 13);
            this.label1.TabIndex = 32;
            this.label1.Text = "ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 33;
            this.label2.Text = "Название";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(49, 126);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 34;
            this.label3.Text = "Адрес";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(49, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 35;
            this.label4.Text = "Рейтинг";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(49, 193);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 13);
            this.label6.TabIndex = 36;
            this.label6.Text = "Фио директора";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(49, 223);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 26);
            this.label7.TabIndex = 37;
            this.label7.Text = "Номер телефона\r\nдиректора";
            // 
            // nudIDt
            // 
            this.nudIDt.Enabled = false;
            this.nudIDt.Location = new System.Drawing.Point(175, 62);
            this.nudIDt.Name = "nudIDt";
            this.nudIDt.Size = new System.Drawing.Size(151, 20);
            this.nudIDt.TabIndex = 38;
            // 
            // txtNameTheatre
            // 
            this.txtNameTheatre.Location = new System.Drawing.Point(175, 89);
            this.txtNameTheatre.Name = "txtNameTheatre";
            this.txtNameTheatre.Size = new System.Drawing.Size(151, 20);
            this.txtNameTheatre.TabIndex = 39;
            // 
            // txtAdress
            // 
            this.txtAdress.Location = new System.Drawing.Point(175, 123);
            this.txtAdress.Name = "txtAdress";
            this.txtAdress.Size = new System.Drawing.Size(151, 20);
            this.txtAdress.TabIndex = 40;
            // 
            // nudRaiting
            // 
            this.nudRaiting.DecimalPlaces = 1;
            this.nudRaiting.Increment = new decimal(new int[] {
            1,
            0,
            0,
            65536});
            this.nudRaiting.Location = new System.Drawing.Point(175, 158);
            this.nudRaiting.Maximum = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.nudRaiting.Name = "nudRaiting";
            this.nudRaiting.Size = new System.Drawing.Size(151, 20);
            this.nudRaiting.TabIndex = 41;
            // 
            // txtNameDirec
            // 
            this.txtNameDirec.Location = new System.Drawing.Point(175, 190);
            this.txtNameDirec.Name = "txtNameDirec";
            this.txtNameDirec.Size = new System.Drawing.Size(151, 20);
            this.txtNameDirec.TabIndex = 42;
            // 
            // mtxtPhoneDirec
            // 
            this.mtxtPhoneDirec.Location = new System.Drawing.Point(175, 223);
            this.mtxtPhoneDirec.Mask = "+70000000000";
            this.mtxtPhoneDirec.Name = "mtxtPhoneDirec";
            this.mtxtPhoneDirec.Size = new System.Drawing.Size(151, 20);
            this.mtxtPhoneDirec.TabIndex = 43;
            // 
            // btnAddNewTheatre
            // 
            this.btnAddNewTheatre.Location = new System.Drawing.Point(49, 303);
            this.btnAddNewTheatre.Name = "btnAddNewTheatre";
            this.btnAddNewTheatre.Size = new System.Drawing.Size(86, 35);
            this.btnAddNewTheatre.TabIndex = 44;
            this.btnAddNewTheatre.Text = "Добавить";
            this.btnAddNewTheatre.UseVisualStyleBackColor = true;
            this.btnAddNewTheatre.Click += new System.EventHandler(this.btnAddNewTheatre_Click);
            // 
            // AddNewTheatre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(372, 369);
            this.Controls.Add(this.btnAddNewTheatre);
            this.Controls.Add(this.mtxtPhoneDirec);
            this.Controls.Add(this.txtNameDirec);
            this.Controls.Add(this.nudRaiting);
            this.Controls.Add(this.txtAdress);
            this.Controls.Add(this.txtNameTheatre);
            this.Controls.Add(this.nudIDt);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label5);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddNewTheatre";
            this.Text = "Добавить театр";
            this.Load += new System.EventHandler(this.AddNewTheatre_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudIDt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudRaiting)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown nudIDt;
        private System.Windows.Forms.TextBox txtNameTheatre;
        private System.Windows.Forms.TextBox txtAdress;
        private System.Windows.Forms.NumericUpDown nudRaiting;
        private System.Windows.Forms.TextBox txtNameDirec;
        private System.Windows.Forms.MaskedTextBox mtxtPhoneDirec;
        private System.Windows.Forms.Button btnAddNewTheatre;
    }
}