﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheaterСompany.Forms
{
    public partial class AddNewTicket : Form
    {
        public AddNewTicket()
        {
            InitializeComponent();
        }

        private void ticketBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();

        }

        private void AddNewTicket_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "databaseTheatreDataSet.User". При необходимости она может быть перемещена или удалена.
            this.userTableAdapter.Fill(this.databaseTheatreDataSet.User);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "databaseTheatreDataSet.Performances". При необходимости она может быть перемещена или удалена.
            this.performancesTableAdapter.Fill(this.databaseTheatreDataSet.Performances);
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            MainForm mf = this.Owner as MainForm;
            if (mf != null)
            {
                DataRow nRow = mf.databaseTheatreDataSet.Tables[3].NewRow();
                nRow[0] = nudID.Value;
                nRow[1] = cmbPerfom.SelectedValue;
                nRow[2] = cmbClient.SelectedValue;
                nRow[3] = nudCountSeit.Value;

                cmbClient.SelectedIndex = 3;

                mf.databaseTheatreDataSet.Tables[3].Rows.Add(nRow);
                mf.ticketTableAdapter.Update(mf.databaseTheatreDataSet.Ticket);
                mf.databaseTheatreDataSet.Tables[3].AcceptChanges();
                mf.MainForm_Load(sender, e);

                nudCountSeit.Value = 1;
            }
        }
    }
}
