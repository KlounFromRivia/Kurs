﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheaterСompany.Forms
{
    public partial class TheatresForm : Form
    {
        public string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\DatabaseTheatre.mdf;Integrated Security=True";
        public TheatresForm()
        {
            InitializeComponent();
        }

        public void TheatresForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "databaseTheatreDataSet.Theaters". При необходимости она может быть перемещена или удалена.
            this.theatersTableAdapter.Fill(this.databaseTheatreDataSet.Theaters);

        }

        private void btnAddTheatre_Click(object sender, EventArgs e)
        {
            AddNewTheatre addNewTheatre = new AddNewTheatre();
            addNewTheatre.Owner = this;
            addNewTheatre.Show();
        }
    }
}
