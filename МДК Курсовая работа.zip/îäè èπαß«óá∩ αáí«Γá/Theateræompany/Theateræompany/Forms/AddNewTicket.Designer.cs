﻿namespace TheaterСompany.Forms
{
    partial class AddNewTicket
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddNewTicket));
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbPerfom = new System.Windows.Forms.ComboBox();
            this.performancesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.databaseTheatreDataSet = new TheaterСompany.DatabaseTheatreDataSet();
            this.performancesTableAdapter = new TheaterСompany.DatabaseTheatreDataSetTableAdapters.PerformancesTableAdapter();
            this.cmbClient = new System.Windows.Forms.ComboBox();
            this.userBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.userTableAdapter = new TheaterСompany.DatabaseTheatreDataSetTableAdapters.UserTableAdapter();
            this.nudCountSeit = new System.Windows.Forms.NumericUpDown();
            this.btnAdd = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.nudID = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.performancesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseTheatreDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCountSeit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudID)).BeginInit();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(33, 146);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(69, 13);
            this.label3.TabIndex = 27;
            this.label3.Text = "Кол-во мест";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 120);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 13);
            this.label2.TabIndex = 26;
            this.label2.Text = "Клиент";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(33, 90);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 25;
            this.label1.Text = "Выступление";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(45, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(220, 25);
            this.label5.TabIndex = 30;
            this.label5.Text = "Заказ нового билета";
            // 
            // cmbPerfom
            // 
            this.cmbPerfom.DataSource = this.performancesBindingSource;
            this.cmbPerfom.DisplayMember = "PerformancesName";
            this.cmbPerfom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPerfom.FormattingEnabled = true;
            this.cmbPerfom.Location = new System.Drawing.Point(123, 87);
            this.cmbPerfom.Name = "cmbPerfom";
            this.cmbPerfom.Size = new System.Drawing.Size(142, 21);
            this.cmbPerfom.TabIndex = 31;
            this.cmbPerfom.ValueMember = "ID_Performances";
            // 
            // performancesBindingSource
            // 
            this.performancesBindingSource.DataMember = "Performances";
            this.performancesBindingSource.DataSource = this.databaseTheatreDataSet;
            // 
            // databaseTheatreDataSet
            // 
            this.databaseTheatreDataSet.DataSetName = "DatabaseTheatreDataSet";
            this.databaseTheatreDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // performancesTableAdapter
            // 
            this.performancesTableAdapter.ClearBeforeFill = true;
            // 
            // cmbClient
            // 
            this.cmbClient.DataSource = this.userBindingSource;
            this.cmbClient.DisplayMember = "Familia_US";
            this.cmbClient.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbClient.FormattingEnabled = true;
            this.cmbClient.Location = new System.Drawing.Point(123, 117);
            this.cmbClient.Name = "cmbClient";
            this.cmbClient.Size = new System.Drawing.Size(142, 21);
            this.cmbClient.TabIndex = 32;
            this.cmbClient.ValueMember = "ID_User";
            // 
            // userBindingSource
            // 
            this.userBindingSource.DataMember = "User";
            this.userBindingSource.DataSource = this.databaseTheatreDataSet;
            // 
            // userTableAdapter
            // 
            this.userTableAdapter.ClearBeforeFill = true;
            // 
            // nudCountSeit
            // 
            this.nudCountSeit.Location = new System.Drawing.Point(123, 144);
            this.nudCountSeit.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.nudCountSeit.Name = "nudCountSeit";
            this.nudCountSeit.ReadOnly = true;
            this.nudCountSeit.Size = new System.Drawing.Size(142, 20);
            this.nudCountSeit.TabIndex = 33;
            this.nudCountSeit.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(32, 193);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 23);
            this.btnAdd.TabIndex = 34;
            this.btnAdd.Text = "Добавить";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // button2
            // 
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.Location = new System.Drawing.Point(201, 192);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 35;
            this.button2.Text = "Отменить";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 63);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(18, 13);
            this.label4.TabIndex = 36;
            this.label4.Text = "ID";
            // 
            // nudID
            // 
            this.nudID.Enabled = false;
            this.nudID.Location = new System.Drawing.Point(123, 61);
            this.nudID.Name = "nudID";
            this.nudID.ReadOnly = true;
            this.nudID.Size = new System.Drawing.Size(142, 20);
            this.nudID.TabIndex = 37;
            // 
            // AddNewTicket
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(302, 255);
            this.Controls.Add(this.nudID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.nudCountSeit);
            this.Controls.Add(this.cmbClient);
            this.Controls.Add(this.cmbPerfom);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AddNewTicket";
            this.Text = "Заказ билет";
            this.Load += new System.EventHandler(this.AddNewTicket_Load);
            ((System.ComponentModel.ISupportInitialize)(this.performancesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseTheatreDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudCountSeit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudID)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbPerfom;
        private DatabaseTheatreDataSet databaseTheatreDataSet;
        private System.Windows.Forms.BindingSource performancesBindingSource;
        private DatabaseTheatreDataSetTableAdapters.PerformancesTableAdapter performancesTableAdapter;
        private System.Windows.Forms.ComboBox cmbClient;
        private System.Windows.Forms.BindingSource userBindingSource;
        private DatabaseTheatreDataSetTableAdapters.UserTableAdapter userTableAdapter;
        private System.Windows.Forms.NumericUpDown nudCountSeit;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nudID;
    }
}