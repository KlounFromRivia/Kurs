﻿namespace TheaterСompany.Forms
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.btnEditTicket = new System.Windows.Forms.Button();
            this.btnAddTicket = new System.Windows.Forms.Button();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsslbl_User = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsslbl_Status_User = new System.Windows.Forms.ToolStripStatusLabel();
            this.grbInfoTicket = new System.Windows.Forms.GroupBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtInfoAdress = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtInfoActor = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dtpInfoPerf = new System.Windows.Forms.DateTimePicker();
            this.txtInfoTheatre = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.lblTheatre = new System.Windows.Forms.Label();
            this.grbTicket = new System.Windows.Forms.GroupBox();
            this.dgvTicket = new System.Windows.Forms.DataGridView();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.tsmiCatalog = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiTheatres = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiActors = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiPerformances = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiExport = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiSpravka = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiСall = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiProgram = new System.Windows.Forms.ToolStripMenuItem();
            this.tsmiExit = new System.Windows.Forms.ToolStripMenuItem();
            this.theatrebindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.databaseTheatreDataSet = new TheaterСompany.DatabaseTheatreDataSet();
            this.ticketTableAdapter = new TheaterСompany.DatabaseTheatreDataSetTableAdapters.TicketTableAdapter();
            this.btnDeleteTicket = new System.Windows.Forms.Button();
            this.hlppSpravka = new System.Windows.Forms.HelpProvider();
            this.ColumnID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnPerfomens = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnClient = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnTheatre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnAdress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnDatePer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnMainActor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnInfo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusStrip1.SuspendLayout();
            this.grbInfoTicket.SuspendLayout();
            this.grbTicket.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvTicket)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.theatrebindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseTheatreDataSet)).BeginInit();
            this.SuspendLayout();
            // 
            // btnEditTicket
            // 
            this.btnEditTicket.Location = new System.Drawing.Point(186, 559);
            this.btnEditTicket.Name = "btnEditTicket";
            this.btnEditTicket.Size = new System.Drawing.Size(114, 36);
            this.btnEditTicket.TabIndex = 11;
            this.btnEditTicket.Text = "Изменить";
            this.btnEditTicket.UseVisualStyleBackColor = true;
            // 
            // btnAddTicket
            // 
            this.btnAddTicket.Location = new System.Drawing.Point(18, 559);
            this.btnAddTicket.Name = "btnAddTicket";
            this.btnAddTicket.Size = new System.Drawing.Size(161, 37);
            this.btnAddTicket.TabIndex = 10;
            this.btnAddTicket.Text = "Заказ билета";
            this.btnAddTicket.UseVisualStyleBackColor = true;
            this.btnAddTicket.Click += new System.EventHandler(this.btnAddTicket_Click);
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsslbl_User,
            this.tsslbl_Status_User});
            this.statusStrip1.Location = new System.Drawing.Point(0, 623);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1178, 22);
            this.statusStrip1.TabIndex = 9;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsslbl_User
            // 
            this.tsslbl_User.Name = "tsslbl_User";
            this.tsslbl_User.Size = new System.Drawing.Size(134, 17);
            this.tsslbl_User.Text = "Текущий пользователь";
            // 
            // tsslbl_Status_User
            // 
            this.tsslbl_Status_User.Name = "tsslbl_Status_User";
            this.tsslbl_Status_User.Size = new System.Drawing.Size(23, 17);
            this.tsslbl_Status_User.Text = "<>";
            // 
            // grbInfoTicket
            // 
            this.grbInfoTicket.Controls.Add(this.textBox1);
            this.grbInfoTicket.Controls.Add(this.label4);
            this.grbInfoTicket.Controls.Add(this.txtInfoAdress);
            this.grbInfoTicket.Controls.Add(this.label3);
            this.grbInfoTicket.Controls.Add(this.txtInfoActor);
            this.grbInfoTicket.Controls.Add(this.label2);
            this.grbInfoTicket.Controls.Add(this.dtpInfoPerf);
            this.grbInfoTicket.Controls.Add(this.txtInfoTheatre);
            this.grbInfoTicket.Controls.Add(this.label1);
            this.grbInfoTicket.Controls.Add(this.lblTheatre);
            this.grbInfoTicket.Location = new System.Drawing.Point(18, 429);
            this.grbInfoTicket.Name = "grbInfoTicket";
            this.grbInfoTicket.Size = new System.Drawing.Size(1126, 106);
            this.grbInfoTicket.TabIndex = 8;
            this.grbInfoTicket.TabStop = false;
            this.grbInfoTicket.Text = "Информация о билетах";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(861, 21);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(259, 50);
            this.textBox1.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(782, 24);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 8;
            this.label4.Text = "Информация";
            // 
            // txtInfoAdress
            // 
            this.txtInfoAdress.Location = new System.Drawing.Point(513, 51);
            this.txtInfoAdress.Name = "txtInfoAdress";
            this.txtInfoAdress.Size = new System.Drawing.Size(229, 20);
            this.txtInfoAdress.TabIndex = 7;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(332, 54);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Адрес";
            // 
            // txtInfoActor
            // 
            this.txtInfoActor.Location = new System.Drawing.Point(513, 21);
            this.txtInfoActor.Name = "txtInfoActor";
            this.txtInfoActor.Size = new System.Drawing.Size(229, 20);
            this.txtInfoActor.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(332, 24);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(175, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Актер в главной роли (Фамилия)";
            // 
            // dtpInfoPerf
            // 
            this.dtpInfoPerf.Location = new System.Drawing.Point(134, 48);
            this.dtpInfoPerf.Name = "dtpInfoPerf";
            this.dtpInfoPerf.Size = new System.Drawing.Size(167, 20);
            this.dtpInfoPerf.TabIndex = 3;
            // 
            // txtInfoTheatre
            // 
            this.txtInfoTheatre.Location = new System.Drawing.Point(134, 21);
            this.txtInfoTheatre.Name = "txtInfoTheatre";
            this.txtInfoTheatre.Size = new System.Drawing.Size(167, 20);
            this.txtInfoTheatre.TabIndex = 2;
            this.txtInfoTheatre.TextChanged += new System.EventHandler(this.txtInfoTheatre_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(26, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Дата выступления";
            // 
            // lblTheatre
            // 
            this.lblTheatre.AutoSize = true;
            this.lblTheatre.Location = new System.Drawing.Point(26, 24);
            this.lblTheatre.Name = "lblTheatre";
            this.lblTheatre.Size = new System.Drawing.Size(37, 13);
            this.lblTheatre.TabIndex = 0;
            this.lblTheatre.Text = "Театр";
            // 
            // grbTicket
            // 
            this.grbTicket.Controls.Add(this.dgvTicket);
            this.grbTicket.Location = new System.Drawing.Point(12, 42);
            this.grbTicket.Name = "grbTicket";
            this.grbTicket.Size = new System.Drawing.Size(1154, 381);
            this.grbTicket.TabIndex = 7;
            this.grbTicket.TabStop = false;
            this.grbTicket.Text = "Билеты";
            // 
            // dgvTicket
            // 
            this.dgvTicket.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvTicket.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnID,
            this.ColumnPerfomens,
            this.ColumnClient,
            this.ColumnTheatre,
            this.ColumnAdress,
            this.ColumnDatePer,
            this.ColumnMainActor,
            this.ColumnInfo});
            this.dgvTicket.Location = new System.Drawing.Point(6, 19);
            this.dgvTicket.Name = "dgvTicket";
            this.dgvTicket.Size = new System.Drawing.Size(1142, 356);
            this.dgvTicket.TabIndex = 0;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiCatalog,
            this.tsmiExport,
            this.tsmiSpravka,
            this.tsmiExit});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1178, 24);
            this.menuStrip1.TabIndex = 6;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // tsmiCatalog
            // 
            this.tsmiCatalog.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiTheatres,
            this.tsmiActors,
            this.tsmiPerformances});
            this.tsmiCatalog.Name = "tsmiCatalog";
            this.tsmiCatalog.Size = new System.Drawing.Size(62, 20);
            this.tsmiCatalog.Text = "Каталог";
            // 
            // tsmiTheatres
            // 
            this.tsmiTheatres.Name = "tsmiTheatres";
            this.tsmiTheatres.Size = new System.Drawing.Size(191, 22);
            this.tsmiTheatres.Text = "Список театров";
            this.tsmiTheatres.Click += new System.EventHandler(this.tsmiTheatres_Click);
            // 
            // tsmiActors
            // 
            this.tsmiActors.Name = "tsmiActors";
            this.tsmiActors.Size = new System.Drawing.Size(191, 22);
            this.tsmiActors.Text = "Список актеров";
            // 
            // tsmiPerformances
            // 
            this.tsmiPerformances.Name = "tsmiPerformances";
            this.tsmiPerformances.Size = new System.Drawing.Size(191, 22);
            this.tsmiPerformances.Text = "Список выступлений";
            this.tsmiPerformances.Click += new System.EventHandler(this.tsmiPerformances_Click);
            // 
            // tsmiExport
            // 
            this.tsmiExport.Name = "tsmiExport";
            this.tsmiExport.Size = new System.Drawing.Size(140, 20);
            this.tsmiExport.Text = "Выходные документы";
            this.tsmiExport.Click += new System.EventHandler(this.tsmiExport_Click);
            // 
            // tsmiSpravka
            // 
            this.tsmiSpravka.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsmiСall,
            this.tsmiProgram});
            this.tsmiSpravka.Name = "tsmiSpravka";
            this.tsmiSpravka.Size = new System.Drawing.Size(65, 20);
            this.tsmiSpravka.Text = "Справка";
            // 
            // tsmiСall
            // 
            this.tsmiСall.Name = "tsmiСall";
            this.tsmiСall.Size = new System.Drawing.Size(156, 22);
            this.tsmiСall.Text = "Вызов справки";
            this.tsmiСall.Click += new System.EventHandler(this.tsmiСall_Click);
            // 
            // tsmiProgram
            // 
            this.tsmiProgram.Name = "tsmiProgram";
            this.tsmiProgram.Size = new System.Drawing.Size(156, 22);
            this.tsmiProgram.Text = "О программе";
            this.tsmiProgram.Click += new System.EventHandler(this.tsmiProgram_Click);
            // 
            // tsmiExit
            // 
            this.tsmiExit.Name = "tsmiExit";
            this.tsmiExit.Size = new System.Drawing.Size(54, 20);
            this.tsmiExit.Text = "Выход";
            this.tsmiExit.Click += new System.EventHandler(this.tsmiExit_Click);
            // 
            // theatrebindingSource
            // 
            this.theatrebindingSource.DataMember = "Ticket";
            this.theatrebindingSource.DataSource = this.databaseTheatreDataSet;
            // 
            // databaseTheatreDataSet
            // 
            this.databaseTheatreDataSet.DataSetName = "DatabaseTheatreDataSet";
            this.databaseTheatreDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ticketTableAdapter
            // 
            this.ticketTableAdapter.ClearBeforeFill = true;
            // 
            // btnDeleteTicket
            // 
            this.btnDeleteTicket.Location = new System.Drawing.Point(312, 559);
            this.btnDeleteTicket.Name = "btnDeleteTicket";
            this.btnDeleteTicket.Size = new System.Drawing.Size(109, 37);
            this.btnDeleteTicket.TabIndex = 12;
            this.btnDeleteTicket.Text = "Удалить";
            this.btnDeleteTicket.UseVisualStyleBackColor = true;
            this.btnDeleteTicket.Click += new System.EventHandler(this.btnDeleteTicket_Click);
            // 
            // hlppSpravka
            // 
            this.hlppSpravka.HelpNamespace = "D:\\Перенос на другой ПК\\Колледж\\МДК Курсовая работа\\TheaterСompany\\TheaterСompany" +
    "\\Resources\\Документ Microsoft Word.docx";
            // 
            // ColumnID
            // 
            this.ColumnID.HeaderText = "ID";
            this.ColumnID.Name = "ColumnID";
            this.ColumnID.Width = 30;
            // 
            // ColumnPerfomens
            // 
            this.ColumnPerfomens.HeaderText = "Выступление";
            this.ColumnPerfomens.Name = "ColumnPerfomens";
            this.ColumnPerfomens.Width = 150;
            // 
            // ColumnClient
            // 
            this.ColumnClient.HeaderText = "Покупатель";
            this.ColumnClient.Name = "ColumnClient";
            this.ColumnClient.Width = 120;
            // 
            // ColumnTheatre
            // 
            this.ColumnTheatre.HeaderText = "Theatre";
            this.ColumnTheatre.Name = "ColumnTheatre";
            this.ColumnTheatre.Width = 150;
            // 
            // ColumnAdress
            // 
            this.ColumnAdress.HeaderText = "Адрес";
            this.ColumnAdress.Name = "ColumnAdress";
            this.ColumnAdress.Width = 200;
            // 
            // ColumnDatePer
            // 
            this.ColumnDatePer.HeaderText = "Дата выступления";
            this.ColumnDatePer.Name = "ColumnDatePer";
            this.ColumnDatePer.Width = 130;
            // 
            // ColumnMainActor
            // 
            this.ColumnMainActor.HeaderText = "Главная роль (актер)";
            this.ColumnMainActor.Name = "ColumnMainActor";
            this.ColumnMainActor.Width = 150;
            // 
            // ColumnInfo
            // 
            this.ColumnInfo.HeaderText = "Информация";
            this.ColumnInfo.Name = "ColumnInfo";
            this.ColumnInfo.Width = 150;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1178, 645);
            this.Controls.Add(this.btnDeleteTicket);
            this.Controls.Add(this.btnEditTicket);
            this.Controls.Add(this.btnAddTicket);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.grbInfoTicket);
            this.Controls.Add(this.grbTicket);
            this.Controls.Add(this.menuStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "Театральная фирма";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.grbInfoTicket.ResumeLayout(false);
            this.grbInfoTicket.PerformLayout();
            this.grbTicket.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvTicket)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.theatrebindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.databaseTheatreDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnEditTicket;
        private System.Windows.Forms.Button btnAddTicket;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsslbl_User;
        private System.Windows.Forms.ToolStripStatusLabel tsslbl_Status_User;
        private System.Windows.Forms.GroupBox grbInfoTicket;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtInfoAdress;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtInfoActor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker dtpInfoPerf;
        private System.Windows.Forms.TextBox txtInfoTheatre;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblTheatre;
        private System.Windows.Forms.GroupBox grbTicket;
        private System.Windows.Forms.DataGridView dgvTicket;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem tsmiCatalog;
        private System.Windows.Forms.ToolStripMenuItem tsmiTheatres;
        private System.Windows.Forms.ToolStripMenuItem tsmiActors;
        private System.Windows.Forms.ToolStripMenuItem tsmiPerformances;
        private System.Windows.Forms.ToolStripMenuItem tsmiExport;
        private System.Windows.Forms.ToolStripMenuItem tsmiSpravka;
        private System.Windows.Forms.ToolStripMenuItem tsmiСall;
        private System.Windows.Forms.ToolStripMenuItem tsmiProgram;
        private System.Windows.Forms.ToolStripMenuItem tsmiExit;
        public System.Windows.Forms.BindingSource theatrebindingSource;
        public DatabaseTheatreDataSet databaseTheatreDataSet;
        public DatabaseTheatreDataSetTableAdapters.TicketTableAdapter ticketTableAdapter;
        private System.Windows.Forms.Button btnDeleteTicket;
        private System.Windows.Forms.HelpProvider hlppSpravka;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnID;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnPerfomens;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnClient;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnTheatre;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnAdress;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnDatePer;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnMainActor;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnInfo;
    }
}