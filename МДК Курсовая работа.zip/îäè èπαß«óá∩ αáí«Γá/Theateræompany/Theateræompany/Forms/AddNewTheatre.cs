﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheaterСompany.Forms
{
    public partial class AddNewTheatre : Form
    {
        public AddNewTheatre()
        {
            InitializeComponent();
        }

        private void theatersBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();

        }

        private void AddNewTheatre_Load(object sender, EventArgs e)
        {
            
        }

        private void btnAddNewTheatre_Click(object sender, EventArgs e)
        {
            Regex regex = new Regex(@"^[А-ЯЁ][а-яё]+ [А-ЯЁ][а-яё]+ [А-ЯЁ][а-яё]+$");

            Match match = regex.Match(txtNameDirec.Text);

            if (match.Success)
            {
                bool flag = txtNameTheatre.Text.Length > 0 && txtAdress.Text.Length > 0 && mtxtPhoneDirec.Text.Length > 10;
                if(flag)
                {
                    TheatresForm tf = this.Owner as TheatresForm;
                    if (tf != null)
                    {
                        DataRow nRow = tf.databaseTheatreDataSet.Tables[2].NewRow();
                        nRow[0] = nudIDt.Value;
                        nRow[1] = txtNameTheatre.Text;
                        nRow[2] = txtAdress.Text;
                        nRow[3] = nudRaiting.Value;
                        nRow[4] = txtNameDirec.Text;
                        nRow[5] = mtxtPhoneDirec.Text;

                        tf.databaseTheatreDataSet.Tables[2].Rows.Add(nRow);
                        tf.theatersTableAdapter.Update(tf.databaseTheatreDataSet.Theaters);
                        tf.databaseTheatreDataSet.Tables[2].AcceptChanges();
                        tf.TheatresForm_Load(sender, e);

                        txtAdress.Text = "";
                        nudRaiting.Value = 0;
                        txtNameDirec.Text = "";
                        mtxtPhoneDirec.Text = "";
                    }
                }
                else
                {
                    MessageBox.Show("Заполните все необходимые поля!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else
            {
                MessageBox.Show("В строке 'Фио директора' нужно полностью ввести ФИО","Ошибка",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }

            
        }
    }
}
