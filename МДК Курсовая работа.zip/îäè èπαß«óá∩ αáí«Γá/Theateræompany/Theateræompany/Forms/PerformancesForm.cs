﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheaterСompany.Forms
{
    public partial class PerformancesForm : Form
    {
        DataView productDataView;
        public string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\DatabaseTheatre.mdf;Integrated Security=True";
        public PerformancesForm()
        {
            InitializeComponent();
        }

        private void PerformancesForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "databaseTheatreDataSet.Theaters". При необходимости она может быть перемещена или удалена.
            this.theatersTableAdapter.Fill(this.databaseTheatreDataSet.Theaters);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "databaseTheatreDataSet.Performances". При необходимости она может быть перемещена или удалена.
            this.performancesTableAdapter.Fill(this.databaseTheatreDataSet.Performances);

            string query =
                "SELECT " +
                "[Performances].[ID_Performances], " +
                "[Performances].[PerformancesName], " +
                "[Theaters].[TheaterName], " +
                "[Performances].[Price], " +
                "[ActorMains].[Familia_AC], " +
                "[Performances].[DateBegin], " +
                "[Performances].[Information] " +
                "FROM " +
                "[Performances], " +
                "[Theaters], " +
                "[ActorMains] " +
                "WHERE " +
                "([Performances].[Theater_id]=[Theaters].[ID_Theaters]) AND" +
                "([Performances].[ActorMains_id]=[ActorMains].[ID_ActorMains]) ";
            Zapros(query);
        }

        private void Zapros(string query)
        {
            dgvTicket.Rows.Clear();

            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            List<string[]> data = new List<string[]>();
            while (reader.Read())
            {
                data.Add(new string[7]);
                data[data.Count - 1][0] = reader[0].ToString();
                data[data.Count - 1][1] = reader[1].ToString();
                data[data.Count - 1][2] = reader[2].ToString();
                data[data.Count - 1][3] = reader[3].ToString();
                data[data.Count - 1][4] = reader[4].ToString();
                data[data.Count - 1][5] = reader[5].ToString();
                data[data.Count - 1][6] = reader[6].ToString();
            }
            reader.Close();
            connection.Close();
            foreach (string[] s in data)
            {
                dgvTicket.Rows.Add(s);
            }
        }

        private void cmbFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            //if (cmbFilter.Text == "Название")
            //{
            //    productDataView = new DataView(productDataView.ToTable(), "", "Title ask", DataViewRowState.CurrentRows);
            //}
            //dgvTicket.DataSource = productDataView.ToTable();
        }

        private System.Windows.Forms.DataGridViewColumn COL;
        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void lstbSort_SelectedIndexChanged(object sender, EventArgs e)
        {
            btnSortPer.Enabled = true;
        }

        private void btnSortPer_Click(object sender, EventArgs e)
        {

            COL = new System.Windows.Forms.DataGridViewColumn();

            switch (lstbSort.SelectedIndex)
            {
                case 0: COL = ColumnPerfomens; break;
                case 1: COL = ColumnTheatre; break;
                case 2: COL = ColumnPrice; break;
            }
            if (rdbVozrat.Checked)
            {
                dgvTicket.Sort(COL, ListSortDirection.Ascending);
            }
            else
            {
                dgvTicket.Sort(COL, ListSortDirection.Descending);
            }
        }
    }
}
