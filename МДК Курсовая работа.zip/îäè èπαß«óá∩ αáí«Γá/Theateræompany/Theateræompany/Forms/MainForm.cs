﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TheaterСompany.Forms
{
    public partial class MainForm : Form
    {
        public string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\DatabaseTheatre.mdf;Integrated Security=True";
        public MainForm()
        {
            InitializeComponent();
            ToolTip tip = new ToolTip();
            tip.SetToolTip(btnDeleteTicket, "Выберите полностью строку, которую хотите удалить");
            tip.SetToolTip(btnAddTicket, "Довабить новый билет");
        }

        private void tsmiProgram_Click(object sender, EventArgs e)
        {
            AboutProgram aboutProgram = new AboutProgram();
            aboutProgram.ShowDialog();
        }

        private void tsmiExit_Click(object sender, EventArgs e)
        {
            base.Close();
        }

        private void tsmiTheatres_Click(object sender, EventArgs e)
        {
            TheatresForm theatresForm = new TheatresForm();
            theatresForm.ShowDialog();
        }

        public void MainForm_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "databaseTheatreDataSet.Ticket". При необходимости она может быть перемещена или удалена.
            this.ticketTableAdapter.Fill(this.databaseTheatreDataSet.Ticket);
            string query =
                "SELECT " +
                "[Ticket].[ID_Ticket], " +
                "[Performances].[PerformancesName], " +
                "[User].[Familia_US], " +
                "[Theaters].[TheaterName], " +
                "[Theaters].[Adress], " +
                "[Performances].[DateBegin], " +
                "[ActorMains].[Familia_AC], " +
                "[Performances].[Information] " +
                "FROM " +
                "[Ticket], " +
                "[Performances], " +
                "[User], " +
                "[Theaters], " +
                "[ActorMains] " +
                "WHERE " +
                "([Ticket].[Performances_id]=[Performances].[ID_Performances]) AND" +
                "([Ticket].[User_id]=[User].[ID_User]) AND" +
                "([Performances].[Theater_id]=[Theaters].[ID_Theaters]) AND" +
                "([Performances].[ActorMains_id]=[ActorMains].[ID_ActorMains]) ";
            Zapros(query);
        }

        private void FindBy(string value)
        {
            string query =
                "SELECT " +
                "[Ticket].[ID_Ticket], " +
                "[Performances].[PerformancesName], " +
                "[User].[Familia_US], " +
                "[Theaters].[TheaterName], " +
                "[Theaters].[Adress], " +
                "[Performances].[DateBegin], " +
                "[ActorMains].[Familia_AC], " +
                "[Performances].[Information] " +
                "FROM " +
                "[Ticket], " +
                "[Performances], " +
                "[User], " +
                "[Theaters], " +
                "[ActorMains] " +
                "WHERE " +
                "([Ticket].[Performances_id]=[Performances].[ID_Performances]) AND" +
                "([Ticket].[User_id]=[User].[ID_User]) AND" +
                "([Performances].[Theater_id]=[Theaters].[ID_Theaters]) AND" +
                "([Performances].[ActorMains_id]=[ActorMains].[ID_ActorMains]) AND" +
                "([Theaters].[TheaterName] = '"+value+"') ";
            Zapros(query);
        }
        private void txtInfoTheatre_TextChanged(object sender, EventArgs e)
        {
            //FindBy(txtInfoTheatre.Text);
            (dgvTicket.DataSource as DataTable).DefaultView.RowFilter =
                String.Format("Theatre like '{0}%'", txtInfoTheatre);
        }

        private void Zapros(string query)
        {
            dgvTicket.Rows.Clear();

            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            List<string[]> data = new List<string[]>();
            while (reader.Read())
            {
                data.Add(new string[8]);
                data[data.Count - 1][0] = reader[0].ToString();
                data[data.Count - 1][1] = reader[1].ToString();
                data[data.Count - 1][2] = reader[2].ToString();
                data[data.Count - 1][3] = reader[3].ToString();
                data[data.Count - 1][4] = reader[4].ToString();
                data[data.Count - 1][5] = reader[5].ToString();
                data[data.Count - 1][6] = reader[6].ToString();
                data[data.Count - 1][7] = reader[7].ToString();
            }
            reader.Close();
            connection.Close();
            foreach (string[] s in data)
            {
                dgvTicket.Rows.Add(s);
            }
        }

        private void btnAddTicket_Click(object sender, EventArgs e)
        {
            AddNewTicket addNewTicket = new AddNewTicket();
            addNewTicket.Owner = this;
            addNewTicket.Show();
        }

        private void btnDeleteTicket_Click(object sender, EventArgs e)
        {
            if (dgvTicket.SelectedRows.Count > 0)
            {
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                SqlCommand command = new SqlCommand("DELETE FROM [Ticket] WHERE ID_Ticket = @pID", connection);
                command.Parameters.Add(new SqlParameter("@pID", this.dgvTicket.CurrentRow.Cells["ColumnID"].Value));
                command.ExecuteNonQuery();
                connection.Close();
                MainForm_Load(sender, e);
            }
        }

        private void tsmiExport_Click(object sender, EventArgs e)
        {
            var xlApp = new Microsoft.Office.Interop.Excel.Application();
            xlApp.Visible = true;

            //Книга
            Microsoft.Office.Interop.Excel.Workbook wBook;
            Microsoft.Office.Interop.Excel.Worksheet xlSheet;
            wBook = xlApp.Workbooks.Add();
            xlApp.Columns.ColumnWidth = 30;

            //Лист
            xlSheet = (Microsoft.Office.Interop.Excel.Worksheet)wBook.Sheets[1];
            //Присвоепние имени листа
            xlSheet.Name = "Билеты";

            //Наименование ккаждого столбца
            xlSheet.Cells[1, 1] = "ID";
            xlSheet.Cells[1, 2] = "Выступление";
            xlSheet.Cells[1, 3] = "Покупатель";
            xlSheet.Cells[1, 4] = "Театр";
            xlSheet.Cells[1, 5] = "Адрес";
            xlSheet.Cells[1, 6] = "Дата выступления";
            xlSheet.Cells[1, 7] = "Главная роль (актер)";
            xlSheet.Cells[1, 8] = "Информация";

            for (int i = 0; i < dgvTicket.Rows.Count - 1; i++)
            {
                for (int j = 0; j < dgvTicket.Columns.Count; j++)
                {
                    xlApp.Cells[i + 2, j + 1] = dgvTicket.Rows[i].Cells[j].Value.ToString();
                }
            }
            xlSheet.Cells.HorizontalAlignment = 3;
            xlApp.Visible = true;
        }

        private void tsmiСall_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this, hlppSpravka.HelpNamespace);
        }

        private void tsmiPerformances_Click(object sender, EventArgs e)
        {
            PerformancesForm pf = new PerformancesForm();
            pf.Owner = this;
            pf.Show();
        }

    }
}
